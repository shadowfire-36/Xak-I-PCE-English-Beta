Add-Type -AssemblyName System.Windows.Forms
$dialog = New-Object System.Windows.Forms.OpenFileDialog
$dialog.Title = 'Select your original or patched Xak disc image'
if ($dialog.ShowDialog() -eq 'OK') {
  $hash = (Get-FileHash -LiteralPath $dialog.FileName -Algorithm SHA256).Hash.ToLower()
  $result = switch ($hash) {
    '3ba67343d89ad199e93acd4724ba044c1177b8b2b1a2ffb593c9e51ac06d3f56' { 'MATCH: correct original image. CRC32 6BD28D3D.' }
    '2d8a56f9c50a76e6b18f0c556ba40b4060803df5cad3cf4155a10ec6198a7e5c' { 'MATCH: Xak I English Beta 2. CRC32 CFC2C6DD.' }
    default { 'NO MATCH: this is neither the required original nor this patched beta.' }
  }
  [System.Windows.Forms.MessageBox]::Show($result + "`r`nSHA-256: " + $hash, 'Xak image check') | Out-Null
}

