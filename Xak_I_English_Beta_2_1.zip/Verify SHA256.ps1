﻿Add-Type -AssemblyName System.Windows.Forms
$dialog = New-Object System.Windows.Forms.OpenFileDialog
$dialog.Title = 'Select your original or patched Xak disc image'
if ($dialog.ShowDialog() -eq 'OK') {
  $hash = (Get-FileHash -LiteralPath $dialog.FileName -Algorithm SHA256).Hash.ToLower()
  $result = switch ($hash) {
    '3ba67343d89ad199e93acd4724ba044c1177b8b2b1a2ffb593c9e51ac06d3f56' { 'MATCH: correct original image. CRC32 6BD28D3D.' }
    'bcf9e90e002c1ada65b048a27b0bfa9eac424835f854ad6e80ea83f3f750c901' { 'MATCH: Xak I English Beta 2.1. CRC32 8694DA8E.' }
    default { 'NO MATCH: this is neither the required original nor this patched beta.' }
  }
  [System.Windows.Forms.MessageBox]::Show($result + "`r`nSHA-256: " + $hash, 'Xak image check') | Out-Null
}

